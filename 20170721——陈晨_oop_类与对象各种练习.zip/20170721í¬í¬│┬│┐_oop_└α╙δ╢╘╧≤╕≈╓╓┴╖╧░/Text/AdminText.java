package Text;

public class AdminText {

	public static void main(String[] args) {
		Administrator am1 = new Administrator();
		Administrator am2 = new Administrator();
		am1.name = "admin1";
		am1.passWord = 123;
		am1.show();

		am2.name = "admin2";
		am2.passWord = 1233456;
		am2.show();
	}
}
