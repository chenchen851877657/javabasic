package Text;

public class ChangeAdminText {

	public static void main(String[] args) {
		ChangeAdmin ch = new ChangeAdmin();
		ch.name = "admin";
		ch.passWord = "111111";
		ch.change();
	}
}
