package Text;

public class IntegralText {

	public static void main(String[] args){
		Integral in=new Integral();
		in.feedBack();
	}
}
