package bookText;

public class Text04Text {

	public static void main(String[] args) {
		Text04_Demo de=new Text04_Demo();
//		Text03_CurrentTime cu=new Text03_CurrentTime();
		de.newTime="2015��5��12��10��11��30�룡";
		de.changeTime();
		de.show();
	}
}
