package bookText;

public class Text04_Demo extends Text03_CurrentTime{

	public String newTime;  //�µ�ʱ��
	
	public void changeTime(){
//		Text03_CurrentTime te=new Text03_CurrentTime();
		super.time=newTime;
	}
	public void show(){
//		Text03_CurrentTime te=new Text03_CurrentTime();
		System.out.println("���ڵ�ʱ����"+super.time);
	}
}
