package shangkelianxi20170721;

public class Student {

	public String name;
	public int age;
	public int classNum;
	public String hobby;
	
	public Student(String name,int classNum,String hobby,int age){
		this.name=name;
		this.age=age;
		this.hobby=hobby;
		this.classNum=classNum;
	}
	
	public void show1(){
		System.out.println(name+"����"+age+"�ꡣ�Ͷ���"
				+classNum+"�ࡣ������"+hobby);
	}
}
