package teacherPptText;

public class AccountText {

	public static void main(String[] args) {
		Account ac=new Account();
		ac.balance=6789.56;
		ac.deposit();
		ac.draw();
		ac.found();
	}
}
