package teacherPptText;

public class Goods {

	public String name;
	public double price;
	public int stock; // ���

	public Goods() {

	}

	public Goods(String name, double price, int stock) {
		this.name = name;
		this.price = price;
		this.stock = stock;
	}

	public void print() {
		System.out.println("��Ʒ����" + name + ",��Ʒ�۸�" + price + ",���Ϊ��" + stock);

	}
}
