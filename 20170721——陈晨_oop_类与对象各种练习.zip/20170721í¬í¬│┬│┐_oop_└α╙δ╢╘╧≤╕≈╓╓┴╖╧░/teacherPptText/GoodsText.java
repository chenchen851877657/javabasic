package teacherPptText;

public class GoodsText {

	public static void main(String[] args) {
		Goods go = new Goods("��С��", 11.12, 100);
		go.print();

	}
}
