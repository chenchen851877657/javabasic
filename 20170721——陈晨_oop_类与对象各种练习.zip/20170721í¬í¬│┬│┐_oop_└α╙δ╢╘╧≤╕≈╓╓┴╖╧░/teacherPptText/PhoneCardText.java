package teacherPptText;

public class PhoneCardText {

	public static void main(String[] args) {
		PhoneCard ph=new PhoneCard("12345","Jack",12.34,"c8518");
//		PhoneCard ph1=new PhoneCard();
		ph.print();
	}
	
}
