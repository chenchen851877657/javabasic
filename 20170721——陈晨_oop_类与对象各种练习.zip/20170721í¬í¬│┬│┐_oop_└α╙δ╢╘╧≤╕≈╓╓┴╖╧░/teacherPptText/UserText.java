package teacherPptText;

public class UserText {

	public static void main(String[] args) {
		User us1 =new User();
		us1.nickName="Lucy";
		us1.age=21;
		us1.regDate="2001-01-03";
		us1.level="�޵�С����";
		us1.showinfo();
		
		System.out.println("==========================");
		
		User us2 =new User();
		us1.nickName="chenchen";
		us1.age=21;
		us1.regDate="2021-11-13";
		us1.level="���ǵ�chenchen";
		us1.showinfo();
		
	}
}
