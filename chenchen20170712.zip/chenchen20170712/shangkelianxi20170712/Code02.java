package shangkelianxi20170712;

import java.util.Scanner;

public class Code02 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("������һ����������");
		int value = sc.nextInt();
		for (int i = 0, j = value; i <= value; i++, j--) {
			System.out.println(i + "+" + j + "=" + (i + j));
		}
	}
}
