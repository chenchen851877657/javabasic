package shangkelianxi20170712;

public class Code04 {

	public static void main(String[] args) {
		int sum = 0;
		for (int i = 1; i <= 10; i++) {
			sum += i;
			if (sum > 20) {
				System.out.println("����20�ĵ�ǰ���ǣ�" + i + ",��Ϊ" + sum);
				break;
			}
		}
	}
}
