package shangkelianxi20170712;

public class Text01 {

	public static void main(String[] args) {
		int count = 0;
		for (int i = 0; i <= 100; i++) {
			if (i % 2 != 0) {
				count += i;
			}
		}
		System.out.println("100���ڵ�����֮��Ϊ��" + count);
	}
}
