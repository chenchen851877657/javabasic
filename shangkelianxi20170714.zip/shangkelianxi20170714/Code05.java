package shangkelianxi20170714;

public class Code05 {

	public static void main(String[] args) {
		int N = 200;
		boolean x = true;
		for (int i = 2; i <= N; i++) {
			
			for (int j = 2; j < i; j++) {
				if (i % j == 0) {
					x = false;
					break;
				}
			}
			if (x == true) {
				System.out.println(i);
			}
		}

	}

}
