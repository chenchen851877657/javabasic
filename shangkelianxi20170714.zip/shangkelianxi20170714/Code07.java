package shangkelianxi20170714;

import java.util.Arrays;

public class Code07 {

	public static void main(String[] args){
		int [] nums={1,2,3,4,5,6,7,8,9};
		int[] arr=Arrays.copyOf(nums, 20);
		System.out.println(Arrays.toString(arr));
		int key=8;
		int index=Arrays.binarySearch(nums, key);
		System.out.println(key+"�������е��±���"+index);
	}
}
