package shangkelianxi20170714;

import java.util.Scanner;

public class Code08 {

	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		int[] scores=new int[5];
		int sum=0;
		for (int i = 0; i < scores.length; i++) {
			System.out.println("������"+(i+1)+"λѧԱ�Ŀ��Գɼ���");
			scores[i]=sc.nextInt();
			sum+=scores[i];
		}
		int max,min;
		max=min=scores[0];
		for (int i = 1; i < scores.length; i++) {
			if(scores[i]>max){
				max=scores[i];
			}
			if(scores[i]<min){
				min=scores[i];
			}
		}
		double avg=sum/scores.length;
		
		System.out.printf("��߷֣�%d ��ͷ֣�%d ƽ���ȣ�%.1f �ܷ֣�%d",max,min,avg,sum);
	}
}
