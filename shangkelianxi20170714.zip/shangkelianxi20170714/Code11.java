package shangkelianxi20170714;

import java.util.Arrays;
import java.util.Scanner;

public class Code11 {

	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		int[] scores={99,85,77,56,34,0};
		int index=scores.length-1;
		System.out.println("�����������ɼ���");
		int num=sc.nextInt();
		for (int i = 0; i < scores.length; i++) {
			if(num>scores[i]){
				index=i;
				break;
			}
		}
		System.out.println("�±�Ϊ��"+index);
		for (int i = scores.length-1; i >index; i--) {
			scores[i]=scores[i-1];
		}
		scores[index]=num;
		System.out.println(Arrays.toString(scores));
	}
}
