package shangkelianxi20170714;

import java.util.Arrays;

public class Code12 {

	public static void main(String[] args){
		char[] ch={'a','c','u','b','e','p','f','z'};
		System.out.println("ԭ�ַ����У�");
		for (int i = 0; i < ch.length; i++) {
			System.out.print(ch[i]+"\t");
		}
		Arrays.sort(ch);
		System.out.println("\n���������");
		for (int i = 0; i < ch.length; i++) {
			System.out.print(ch[i]+"\t");
		}
		System.out.println("\n�������Ϊ��");
		for (int i = ch.length-1; i>=0; i--) {
			System.out.print(ch[i]+"\t");
		}
	}
}
