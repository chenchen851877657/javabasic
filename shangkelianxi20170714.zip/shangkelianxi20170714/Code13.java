package shangkelianxi20170714;

import java.util.Arrays;
import java.util.Scanner;

public class Code13 {

	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		System.out.print("����ǰ��");
		char[] ch={'a','b','c','e','f','p','u','z',' '};
		for (int i = 0; i < ch.length; i++) {
			System.out.print(ch[i]+" ");
		}
		System.out.println();
		int index=ch.length-1;
		System.out.print("��������ַ��ǣ�");
		char a=sc.next().charAt(0);
		for (int i = 0; i < ch.length; i++) {
			if(a<ch[i]){
				index=i;
				break;
			}
		}
		System.out.println("�����ַ����±��ǣ�"+index);
		for (int i = ch.length-1; i >index; i--) {
			ch[i]=ch[i-1];
		}
		ch[index]=a;
		System.out.print("�������ַ������ǣ�");
		for (int i = 0; i < ch.length; i++) {
			System.out.print(ch[i]+" ");
		}
//		System.out.println(Arrays.toString(ch));
	}
}
