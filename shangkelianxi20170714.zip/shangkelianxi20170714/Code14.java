package shangkelianxi20170714;

import java.util.Scanner;

public class Code14 {

	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		//����һ������Ķ�ά����
//		int[][] scores=new int[3][5];
//		scores[0][0]=89;
//		scores[0][1]=81;
//		scores[0][2]=82;
//		scores[0][3]=83;
//		scores[0][4]=84;
//		
//		scores[1][0]=69;
//		scores[1][1]=71;
//		scores[1][2]=82;
//		scores[1][3]=93;
//		scores[1][4]=94;
//		
//		scores[2][0]=99;
//		scores[2][1]=89;
//		scores[2][2]=99;
//		scores[2][3]=73;
//		scores[2][4]=84;
		double[][] scores =new double[3][];
		int total;
		for (int i = 0; i < scores.length; i++) {
			System.out.println("�������"+(i+1)+"����ѧԱ�ɼ�");
			total=0;
			for (int j = 0; j < scores.length; j++) {
				System.out.println("");
				scores[i][j]=sc.nextDouble();
				total+=scores[i][j];
			}
		}
		
		for (int i = 0; i < scores.length; i++) {
			for (int j = 0; j < scores[i].length; j++) {
				System.out.print("scores["+i+"]["+j+"]="+scores[i][j]+"\t");
			}
			System.out.println("\n");
		}
	}
}
