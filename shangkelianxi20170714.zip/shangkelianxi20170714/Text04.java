package shangkelianxi20170714;

public class Text04 {

	public static void main(String[] args) {
		int[] arrays = new int[] { 1, 3, -1, 5, -2 };
		int[] newArrays = new int[5];
		System.out.println("ԭ����Ϊ��");
		for (int i = 0; i < arrays.length; i++) {
			System.out.print(arrays[i] + " ");
		}
		for (int i = 0; i < newArrays.length; i++) {
			if (arrays[newArrays.length - i - 1] < 0) {
				newArrays[i] = 0;
			} else {
				newArrays[i] = arrays[newArrays.length - i - 1];
			}
		}
		System.out.println();
		System.out.println("���򲢴����������Ϊ��");
		for (int i = 0; i < newArrays.length; i++) {
			System.out.print(newArrays[i] + " ");
		}
	}
}
