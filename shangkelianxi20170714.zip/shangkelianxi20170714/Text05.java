package shangkelianxi20170714;

import java.util.Scanner;

public class Text05 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String[] st = { "Island", "Ocean", "Pretty", "Sun", " " };
		String a;
		int index = 0;
		System.out.print("����ǰ������Ϊ��");
		for (int i = 0; i < st.length; i++) {
			System.out.print(st[i] + " ");
		}
		System.out.print("\n������������ƣ�");
		a = sc.next();
		for (int i = 0; i < st.length - 1; i++) {
			if (a.compareToIgnoreCase(st[i]) < 0) {
				index = i;
			}
		}
		for (int i = st.length - 1; i > index; i--) {
			st[i] = st[i - 1];
		}
		st[index] = a;
		System.out.print("����������Ϊ��");
		for (int i = 0; i < st.length; i++) {
			System.out.print(st[i] + " ");
		}
	}
}
