package shangkelianxi20170714;

public class Text08 {

	public static void main(String[] args){
		int[] nums={22,11,33,15,23,12,14,55};
		int count=0;
		int max=nums[0];
		int min=nums[0];
		for (int i = 0; i < nums.length; i++) {
			if(max<nums[i]){
				max=nums[i];
			}
			if(min>nums[i]){
				min=nums[i];
			}
			count+=nums[i];
		}
		System.out.println("����Ԫ�صĺ�Ϊ��"+count);
		System.out.println("���ֵΪ��"+max+"\t��СֵΪ��"+min);
		
	}
}
