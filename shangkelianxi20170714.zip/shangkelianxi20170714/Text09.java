package shangkelianxi20170714;

import java.util.Arrays;
import java.util.Scanner;

public class Text09 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int[][] scores = new int[20][5];
		int[] arr = new int[20];
		// ��ά���鸳ֵ
		for (int i = 0; i < scores.length; i++) {
			for (int j = 0; j < scores[i].length; j++) {
				scores[i][j] = (int) (Math.random() * 100);
			}
		}
		// ��ά�������
		for (int i = 0; i < scores.length; i++) {
			System.out.println("��" + (i + 1) + "λͬѧ�ĸ���ɼ�Ϊ��");
			int count = 0;
			for (int j = 0; j < scores[i].length; j++) {
				count += scores[i][j];
				System.out.println("\t" + scores[i][j]);
			}
			arr[i] = count;
		}
		System.out.println(Arrays.toString(arr));
		System.out.println("������Ҫ��ѯ��ѧ�ƣ���1.C++ 2.Java 3.Python 4.C# 5.C��");
		int num = sc.nextInt();
		int sum = 0, avg = 0;
		switch (num) {
			case 1: {
				for (int i = 0; i < arr.length; i++) {
					sum += scores[i][0];
				}
				break;
			}
			case 2: {
				for (int i = 0; i < arr.length; i++) {
					sum += scores[i][1];
				}
				break;
			}
			case 3: {
				for (int i = 0; i < arr.length; i++) {
					sum += scores[i][2];
				}
				break;
			}
			case 4: {
				for (int i = 0; i < arr.length; i++) {
					sum += scores[i][3];
				}
				break;
			}
			case 5: {
				for (int i = 0; i < arr.length; i++) {
					sum += scores[i][4];
				}
				break;
			}
		}
		avg = sum / scores.length;
		System.out.println("���ſε�ƽ����Ϊ��" + avg);
	}
}
