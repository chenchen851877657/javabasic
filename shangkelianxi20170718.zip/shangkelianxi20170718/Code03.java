package shangkelianxi20170718;

public class Code03 {

	public static void main(String[] args){
		System.out.println("打印矩形");
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 8; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
}
