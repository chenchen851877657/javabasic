package shangkelianxi20170718;

import java.util.Arrays;

public class Code08 {

	public static void main(String[] args){
		int[] nums={56,3,67,45,89};
		int temp=0;
		for (int i = 0; i < nums.length-1; i++) {
			/**
			 * ��i=0ʱ��i<4 true
			 */
			for (int j = 0; j < nums.length-1-i; j++) {
				if (nums[j]>nums[j+1]) {
					temp=nums[j];
					nums[j]=nums[j+1];
					nums[j+1]=temp;
				}
			}
		}
		for(int i:nums){
			System.out.print(i+" ");
		}
		System.out.println(Arrays.toString(nums));
		
	}
}
