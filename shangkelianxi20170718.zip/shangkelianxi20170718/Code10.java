package shangkelianxi20170718;

public class Code10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 1;
		int j = 1,k=0;
		for (; i <= 67; i++) {
			for (; j < 56; j++) {
				k=i*j;
				System.out.println(k);
			}
		}
	}

}
