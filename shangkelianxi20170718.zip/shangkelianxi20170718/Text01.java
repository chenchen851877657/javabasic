package shangkelianxi20170718;

public class Text01 {
	// ��ӡһ�����ľ���
	public static void main(String[] args) {
		for (int i = 1; i <= 6; i++) {
			if (i == 1 || i == 6) {
				for (int j = 1; j <= 16; j++) {
					System.out.print("*");
				}
				System.out.println();
			} else {
				for (int j = 1; j <= 16; j++) {
					if (j == 1 || j == 16) {
						System.out.print("*");
					} else {
						System.out.print(" ");
					}
				}
				System.out.println();
			}
		}
	}
}
