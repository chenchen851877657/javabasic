package shangkelianxi20170711;

public class Code03 {

	public static void main(String[] args) {
		int num = 25, year = 2012;
		while (num < 100) {
			num *= 1.25;
			year++;
		}
		System.out.println(year + "��ﵽ" + num + "���ˣ�");
	}
}
