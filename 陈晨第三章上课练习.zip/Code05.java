package shangkelianxi20170711;

public class Code05 {

	public static void main(String[] args){
		double she=0,hua=0;
		int i=0;
		while(she<=250&&i<10){
			hua=she*9/5.0+32;
			System.out.println("���϶ȣ�"+she+"���϶ȣ�"+hua);
			she+=20;
		}
	}
}
