package shangkelianxi20170711;

public class Code06 {

	public static void main(String[] args){
		double she=0,hua=0,i=0;
		do{
			hua=she*9/5.0+32;
			System.out.println("���϶ȣ�"+she+"���϶ȣ�"+hua);
			she+=20;
			i++;
		}while(she<=250&&i<10);
	}
}
