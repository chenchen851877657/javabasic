package shangkelianxi20170711;

public class Text01 {

	public static void main(String[] args) {
		int i = 1, sum = 0;
		while (i <= 100) {
			sum += i;
			i++;
		}
		System.out.println("1�ӵ�100��ֵΪ��" + sum);

		int j = 1;
		sum = 0;
		do {
			sum += j;
			j++;
		} while (j <= 100);
		System.out.println("1�ӵ�100��ֵΪ��" + sum);
	}
}
