package shangkelianxi20170711;

public class Text02 {

	public static void main(String[] args) {
		int i = 1, sum = 1;
		while (i <= 10) {
			sum *= i;
			i++;
		}
		System.out.println("10�Ľ׳��ǣ�" + sum);

		int j = 1;
		sum = 1;
		do {
			sum *= j;
			j++;
		} while (j <= 10);
		System.out.println("10�Ľ׳��ǣ�" + sum);
	}
}
